const Rating = require('../models/rating');
const Recipe = require('../models/recipe');

exports.addRating = async (req, res) => {
  try {
    const { value, recipeId } = req.body;

    const recipe = await Recipe.findById(recipeId);
    if (!recipe) {
      return res.status(404).json({ message: 'Recipe not found' });
    }

    const newRating = new Rating({
      value,
      user: req.user._id, 
      recipe: recipeId
    });

    await newRating.save();
    res.status(201).json({ message: 'Rating added successfully', rating: newRating });
  } catch (error) {
    res.status(500).json({ message: 'Error adding rating', error });
  }
};

exports.getAverageRating = async (req, res) => {
  try {
    const ratings = await Rating.find({ recipe: req.params.recipeId });
    if (ratings.length === 0) {
      return res.status(404).json({ message: 'No ratings found for this recipe' });
    }

    const averageRating = ratings.reduce((acc, rating) => acc + rating.value, 0) / ratings.length;
    res.status(200).json({ averageRating });
  } catch (error) {
    res.status(500).json({ message: 'Error calculating average rating', error });
  }
};
