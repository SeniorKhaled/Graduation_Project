const Comment = require('../models/comment');
const Recipe = require('../models/recipe');

exports.createComment = async (req, res) => {
  try {
    const { text, recipeId } = req.body;

    const recipe = await Recipe.findById(recipeId);
    if (!recipe) {
      return res.status(404).json({ message: 'Recipe not found' });
    }

    const newComment = new Comment({
      text,
      author: req.user._id, 
      recipe: recipeId
    });

    await newComment.save();
    res.status(201).json({ message: 'Comment added successfully', comment: newComment });
  } catch (error) {
    res.status(500).json({ message: 'Error adding comment', error });
  }
};

exports.getCommentsByRecipe = async (req, res) => {
  try {
    const comments = await Comment.find({ recipe: req.params.recipeId }).populate('author', 'username');
    res.status(200).json(comments);
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving comments', error });
  }
};


exports.getAllComments = async (req, res) => {
  try {
    const comments = await Comment.find()
      .populate('author', 'username')
      .populate('recipe', 'title');
    res.status(200).json(comments);
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving all comments', error });
  }
};

exports.getCommentById = async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id)
      .populate('author', 'username')
      .populate('recipe', 'title');
    
    if (!comment) {
      return res.status(404).json({ message: 'Comment not found' });
    }

    res.status(200).json(comment);
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving comment', error });
  }
};
