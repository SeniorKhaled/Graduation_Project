const Recipe = require('../models/recipe');
const User = require('../models/user');
const Comment = require('../models/comment');
const Rating = require('../models/rating'); 

exports.createRecipe = async (req, res) => {
  try {
    const { title, description, ingredients, steps, image, userId } = req.body;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(400).json({ message: 'User not found' });
    }

    const newRecipe = new Recipe({
      title,
      description,
      ingredients,
      steps,
      image,
      author: userId,
    });

    await newRecipe.save();
    res.status(201).json({ message: 'Recipe created successfully', recipe: newRecipe });
  } catch (error) {
    res.status(500).json({ message: 'Error creating recipe', error });
  }
};

exports.getRecipes = async (req, res) => {
  try {
    const recipes = await Recipe.find()
      .populate('author', 'username') 
      .populate('comments')
      .populate('ratings');
    res.status(200).json(recipes);
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving recipes', error });
  }
};

exports.getRecipeById = async (req, res) => {
  try {
    const recipe = await Recipe.findById(req.params.id)
      .populate('author', 'username')
      .populate('comments')
      .populate('ratings');
    if (!recipe) {
      return res.status(404).json({ message: 'Recipe not found' });
    }
    res.status(200).json(recipe);
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving recipe', error });
  }
};

exports.updateRecipe = async (req, res) => {
  try {
    const { title, description, ingredients, steps, image } = req.body;
    const updatedRecipe = await Recipe.findByIdAndUpdate(
      req.params.id,
      { title, description, ingredients, steps, image },
      { new: true } 
    );
    if (!updatedRecipe) {
      return res.status(404).json({ message: 'Recipe not found' });
    }
    res.status(200).json({ message: 'Recipe updated successfully', recipe: updatedRecipe });
  } catch (error) {
    res.status(500).json({ message: 'Error updating recipe', error });
  }
};

exports.deleteRecipe = async (req, res) => {
  try {
    const deletedRecipe = await Recipe.findByIdAndDelete(req.params.id);
    if (!deletedRecipe) {
      return res.status(404).json({ message: 'Recipe not found' });
    }
    res.status(200).json({ message: 'Recipe deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting recipe', error });
  }
};
