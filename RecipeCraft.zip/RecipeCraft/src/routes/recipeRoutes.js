const express = require('express');
const router = express.Router();
const recipeController = require('../controllers/recipeController');
const authMiddleware = require('../middleware/authMiddleware'); // Optional: if you need authentication for certain routes

router.post('/recipes', authMiddleware, recipeController.createRecipe);

router.get('/recipes', recipeController.getRecipes);

router.get('/recipes/:id', recipeController.getRecipeById);

router.put('/recipes/:id', authMiddleware, recipeController.updateRecipe);

router.delete('/recipes/:id', authMiddleware, recipeController.deleteRecipe);

module.exports = router;
