const express = require('express');
const router = express.Router();
const commentController = require('../controllers/commentController');
const authMiddleware = require('../middleware/authMiddleware'); 

router.post('/comments', authMiddleware, commentController.createComment);

router.get('/comments/:recipeId', commentController.getCommentsByRecipe);

router.get('/comments', commentController.getAllComments);

router.get('/comment/:id', commentController.getCommentById);

module.exports = router;
