const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');
const userRoutes = require('./src/routes/userRoutes'); 
const recipeRoutes = require('./src/routes/recipeRoutes');
const commentRoutes = require('./src/routes/commentRoutes');
const ratingRoutes = require('./src/routes/ratingRoutes');
dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

app.use('/api', userRoutes); 
app.use('/api', recipeRoutes);
app.use('/api', commentRoutes);
app.use('/api', ratingRoutes);
// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
